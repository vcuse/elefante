﻿using System;
using System.Threading;

namespace Mycobot.csharp
{
    class Test
    {
        static void Main(string[] args)
        {
            MyCobot mc = new MyCobot("COM3");
            MyCobot mc2 = new MyCobot("COM4");
            //Raspberry Pi robotic arm serial port name: / dev / ttyAMA0
            
            mc.Open();
            mc2.Open();

            //After Windows opens the serial port, you need to wait for 5s.
            //After Windows opens the serial port, the basic at the bottom will restart.
            Thread.Sleep(5000);

            /*
            int[] coords = new[] {0, 0, 0, 0, 0, 0};
            mc.SendCoords(coords, 80, 1);
            Thread.Sleep(5000);
            var recCoords = mc.GetCoords();
            foreach (var v in recCoords)
            {
                Console.WriteLine(v);
            }*/

    
            Console.WriteLine("...Performing First Movement");
            int[] angles = new[] {90, 0, 0, 0, 0, 0};
            mc.SendAngles(angles, 80);
            mc2.SendAngles(angles, 80);
            Thread.Sleep(5000);

            Console.WriteLine("Gertrude:");
            var recAngles = mc.GetAngles();
            foreach (var v in recAngles)
            {
               Console.WriteLine(v);
            }

            Console.WriteLine("Sir:");
            recAngles = mc2.GetAngles();
            foreach (var v in recAngles)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine();

            Console.WriteLine("...Performing Second Movememnt");
            angles = new[] { 180, 0, 0, 0, 0, 0 };
            mc.SendAngles(angles, 80);
            mc2.SendAngles(angles, 80);
            Thread.Sleep(5000);

            Console.WriteLine("Gertrude:");
            recAngles = mc.GetAngles();
            foreach (var v in recAngles)
            {
                Console.WriteLine(v);
            }

            Console.WriteLine("Sir:");
            recAngles = mc2.GetAngles();
            foreach (var v in recAngles)
            {
                Console.WriteLine(v);
            }
            Console.WriteLine();

            mc.Close();
            mc2.Close();
        }
    }
}