# Notice For Use
## There is no display on the screen after burning
## You need to connect the serial port and turn on the serial assistant
## Baud rate = 9600
## At this time, key A/B corresponds to different steering gear parameters
## Button A corresponds to the PID parameter with accurate repeatable positioning accuracy
## Button B is the PID parameter with good execution of corresponding path
## Press C to read the PID parameters of the current steering gear
