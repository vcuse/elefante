A very simple transponder for the MyCobot Basic: forwards messages from the USB serial port to the Atom, and vice versa.
