#include "ServerBase.h"
#include <MyCobotBasic.h>
ServerBase::ServerBase()
{
    //todo
}
ServerBase::~ServerBase()
{
    //todo
}
